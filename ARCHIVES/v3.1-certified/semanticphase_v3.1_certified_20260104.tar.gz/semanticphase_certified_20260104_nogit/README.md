# SemanticPhase Polysemy Disambiguation - Certified

This repository contains the **immutable evidence bundle** proving that our SemanticPhase v3 model can reliably distinguish between different meanings of the same word (polysemy disambiguation).

## What This Is

We trained a neural network to understand that "bank" in *"I deposited money at the bank"* means something different than "bank" in *"We walked along the river bank"* — and we proved it works **reproducibly** across 3 independent training runs.

## What It Demonstrates

| Metric | Result |
|--------|--------|
| Seeds tested | 3 (42, 123, 456) |
| Seeds passed | **3/3** |
| Late-window success rate | **95.4%** (threshold was 30%) |
| Margin headroom | **+1.50** average (positive = winning) |

The model consistently separates hard negative pairs (same word, different meaning, similar context) with large margins — not just once, but across different random initializations.

## How to Verify (3 Steps)

### Step 1: Check the checksums
```bash
cd semanticphase_certified_20260104_nogit
sha256sum -c SHA256SUMS.txt
# All files should show "OK"
```

### Step 2: Read the results
Open `logs/validation_3seed_full.log` and scroll to the bottom:
```
Seeds passed: 3/3
Avg best MSR: 100.0%
Verdict: PASSED
```

### Step 3: Reproduce (optional)
With the original bundle file (MD5: `8f4e13b7ae4ab5e793ea47f2a80000a4`):
```powershell
./REPRO_COMMANDS.ps1 -BundlePath "path/to/dress_rehearsal_bundles.jsonl"
```
You should get the same ~95% late-window success rate.

---

**Full technical details:** See [CERTIFICATION_NOTE.md](./CERTIFICATION_NOTE.md)

*Certified: 2026-01-04*
